import './globals.css';
export const metadata={title:'BibleVerse — Read. Understand. Pray. Grow.',description:'A vibrant Christian ecosystem for Scripture, prayer, study, learning and AI-assisted Bible exploration.'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
