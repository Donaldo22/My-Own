# BibleVerse

Read. Understand. Pray. Grow.

A polished Next.js prototype for a modern Christian digital ecosystem. The current build focuses on a high-quality responsive product shell with functional navigation, Bible reading/parallel comparison, Pastor AI interaction, Bible-for-Life hub, reading progress, challenges, profile growth and mobile navigation.

## Run

npm install
npm run dev

## Production

npm run build
npm start

## Content & licensing

The UI intentionally uses short sample Scripture content. Do not ship copyrighted translation text without the appropriate license. Add translations through a provider/content layer with per-translation license metadata. Public-domain/openly licensed content can be bundled for offline use when its license permits it.

## Suggested production architecture

- Next.js App Router + TypeScript
- Postgres + pgvector for semantic Bible/topic retrieval
- Object storage/CDN for audio and media
- Auth provider with secure sessions
- Translation adapter layer for public-domain, open-license, licensed and external/API sources
- RAG pipeline that retrieves verified Scripture/context before AI generation
- Separate labels for Scripture text, historical context, denominational interpretation and AI explanation
- Moderation/reporting layer for community features
- Offline cache using IndexedDB/service worker for permitted content
